import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './contexts/LanguageContext';
import { WorldPortal } from './worlds/WorldPortal';
import { NewsWorld } from './worlds/news/NewsWorld';
import { ScienceWorld } from './worlds/science/ScienceWorld';
import { BooksWorld } from './worlds/books/BooksWorld';

export default function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<WorldPortal />} />
          <Route path="/news" element={<NewsWorld />} />
          <Route path="/science" element={<ScienceWorld />} />
          <Route path="/books" element={<BooksWorld />} />
        </Routes>
      </BrowserRouter>
    </LanguageProvider>
  );
}
