/**
 * components/script/ScriptModal.jsx
 */

import { useEffect, useRef } from 'react';
import { X, Zap, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import clsx from 'clsx';
import { PlatformSelector, StyleSelector } from './PlatformStyleSelector';
import { ScriptOutput } from './ScriptOutput';
import { getScoreClasses, formatRelativeTime, PLATFORM_CONFIG, STYLE_CONFIG } from '../../utils';
import { useLang } from '../../contexts/LanguageContext';
import { t } from '../../i18n/translations';

const VERSION_LABELS = ['Version 1', 'Version 2', 'Version 3'];

export function ScriptModal({ article, onClose, generator }) {
  const { lang } = useLang();
  const tx = t[lang];
  const overlayRef = useRef(null);

  const {
    platform, setPlatform,
    style, setStyle,
    script, loading, error, hooksLoading,
    currentVersion,
    generate, generateVersion,
    regenerateHooks,
    saveScript,
    reset,
  } = generator;

  const scoreClasses = getScoreClasses(article?.viral_score || 0);

  const handleOverlayClick = (e) => {
    if (e.target === overlayRef.current) onClose();
  };

  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  if (!article) return null;

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 modal-overlay"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)' }}
      onClick={handleOverlayClick}
    >
      <div className="modal-content w-full sm:max-w-5xl max-h-[95vh] sm:max-h-[90vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-dark-800 border border-white/5 overflow-hidden">

        {/* Header */}
        <div className="flex items-start gap-4 p-5 border-b border-white/5 flex-shrink-0">
          {article.image && (
            <img
              src={article.image}
              alt={article.title}
              className="w-14 h-14 rounded-xl object-cover flex-shrink-0 border border-white/10"
              onError={(e) => (e.target.style.display = 'none')}
            />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-body text-white/30">{article.source}</span>
              <span className="text-white/10">·</span>
              <span className="text-xs font-body text-white/30">{formatRelativeTime(article.publishedAt)}</span>
              <span className={clsx('ml-auto flex items-center gap-1 font-mono text-xs font-bold flex-shrink-0', scoreClasses.text)}>
                <Zap size={10} fill="currentColor" />
                {article.viral_score}/10
              </span>
            </div>
            <h2 className="font-display font-semibold text-white text-sm sm:text-base leading-snug line-clamp-2">
              {article.title}
            </h2>
          </div>
          <button onClick={onClose} className="btn-ghost flex-shrink-0 -mt-1 -mr-1">
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="flex flex-col sm:flex-row flex-1 overflow-hidden">
          {/* Left panel */}
          <div className="w-full sm:w-72 flex-shrink-0 p-5 space-y-5 border-b sm:border-b-0 sm:border-r border-white/5 overflow-y-auto">
            <PlatformSelector value={platform} onChange={(val) => { setPlatform(val); reset(); }} />
            <StyleSelector value={style} onChange={(val) => { setStyle(val); reset(); }} />

            {script && (
              <div className="space-y-2">
                <p className="section-label">{tx.scriptVersions}</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {VERSION_LABELS.map((label, i) => (
                    <button
                      key={i}
                      disabled={loading}
                      onClick={() => generateVersion(article, i + 1)}
                      className={clsx(
                        'py-1.5 rounded-lg text-xs font-body transition-all duration-200',
                        currentVersion === i + 1
                          ? 'bg-brand-500 text-white font-medium'
                          : 'bg-dark-700 text-white/40 hover:text-white/70 border border-white/5'
                      )}
                    >
                      V{i + 1}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => generate(article, 1)}
              disabled={loading}
              className="btn-primary w-full justify-center"
            >
              {loading ? (
                <><Loader2 size={16} className="animate-spin" />{tx.generating}</>
              ) : (
                <><Zap size={16} fill="currentColor" />{script ? tx.regenerate : tx.generate}</>
              )}
            </button>

            <div className="bg-dark-700 border border-white/5 rounded-xl p-3 space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/30 font-body w-16">{tx.platform}</span>
                <span className="text-xs font-body text-white/70">{PLATFORM_CONFIG[platform]?.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/30 font-body w-16">{tx.style}</span>
                <span className="text-xs font-body text-white/70">{STYLE_CONFIG[style]?.label}</span>
              </div>
            </div>
          </div>

          {/* Right panel */}
          <div className="flex-1 p-5 overflow-y-auto">
            {loading && (
              <div className="flex flex-col items-center justify-center h-full gap-4 min-h-48">
                <div className="w-16 h-16 rounded-2xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center">
                  <Zap size={28} className="text-brand-400 animate-pulse" fill="currentColor" />
                </div>
                <div className="text-center">
                  <p className="font-display font-semibold text-white mb-1">{tx.craftingScript}</p>
                  <p className="text-sm text-white/40 font-body">{tx.aiAnalyzing}</p>
                </div>
              </div>
            )}

            {!loading && error && (
              <div className="flex flex-col items-center justify-center h-full gap-4 min-h-48">
                <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                  <AlertCircle size={22} className="text-red-400" />
                </div>
                <div className="text-center">
                  <p className="font-display font-semibold text-white mb-1">{tx.generationFailed}</p>
                  <p className="text-sm text-white/40 font-body max-w-sm">{error}</p>
                </div>
                <button onClick={() => generate(article)} className="btn-secondary">
                  <RefreshCw size={14} />{tx.tryAgain}
                </button>
              </div>
            )}

            {!loading && !error && !script && (
              <div className="flex flex-col items-center justify-center h-full gap-4 min-h-48 text-center">
                <div className="w-16 h-16 rounded-2xl bg-dark-700 border border-white/5 flex items-center justify-center">
                  <Zap size={28} className="text-white/20" />
                </div>
                <div>
                  <p className="font-display font-semibold text-white mb-2">{tx.readyToGenerate}</p>
                  <p className="text-sm text-white/40 font-body max-w-xs">
                    {tx.selectAndClick}{' '}
                    <span className="text-brand-400">{tx.generate}</span>.
                  </p>
                </div>
              </div>
            )}

            {!loading && !error && script && (
              <ScriptOutput
                script={script}
                article={article}
                onRegenerateHooks={() => regenerateHooks(article)}
                hooksLoading={hooksLoading}
                onSave={() => saveScript(article)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
