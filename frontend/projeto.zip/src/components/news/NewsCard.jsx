/**
 * components/news/NewsCard.jsx
 */

import { Zap, ExternalLink, Clock } from 'lucide-react';
import clsx from 'clsx';
import { truncate, formatRelativeTime, getScoreClasses } from '../../utils';

export function NewsCard({ article, onClick, index = 0 }) {
  const scoreClasses = getScoreClasses(article.viral_score);

  const handleClick = (e) => {
    e.preventDefault();
    onClick(article);
  };

  return (
    <div
      className="glass-card-hover cursor-pointer overflow-hidden group animate-fade-in"
      style={{ animationDelay: `${index * 50}ms`, animationFillMode: 'backwards' }}
      onClick={handleClick}
    >
      {/* Image */}
      <div className="relative h-44 overflow-hidden bg-dark-700">
        {article.image ? (
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.nextSibling.style.display = 'flex';
            }}
          />
        ) : null}
        {/* Fallback */}
        <div
          className={clsx(
            'absolute inset-0 flex items-center justify-center',
            article.image ? 'hidden' : 'flex'
          )}
          style={{ background: 'linear-gradient(135deg, #1a1a24 0%, #111118 100%)' }}
        >
          <span className="text-4xl opacity-30">📰</span>
        </div>

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-dark-800/80 to-transparent" />

        {/* Viral score badge */}
        <div
          className={clsx(
            'absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg',
            'border backdrop-blur-sm animate-score-pop',
            scoreClasses.bg
          )}
        >
          <Zap size={11} className={clsx(scoreClasses.text)} fill="currentColor" />
          <span className={clsx('font-mono text-xs font-bold', scoreClasses.text)}>
            {article.viral_score}/10
          </span>
        </div>

        {/* Source */}
        <div className="absolute bottom-3 left-3">
          <span className="text-xs font-body font-medium text-white/70 bg-dark-900/70 backdrop-blur-sm px-2 py-1 rounded-md">
            {article.source}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Score label */}
        <div className="flex items-center gap-2">
          <span className={clsx('w-1.5 h-1.5 rounded-full flex-shrink-0', scoreClasses.dot)} />
          <span className={clsx('text-xs font-mono font-semibold tracking-wider', scoreClasses.text)}>
            {article.score_label}
          </span>
          <div className="flex-1" />
          <div className="flex items-center gap-1 text-white/30 text-xs font-body">
            <Clock size={10} />
            <span>{formatRelativeTime(article.publishedAt)}</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="font-display font-semibold text-white text-sm leading-snug line-clamp-3 group-hover:text-brand-300 transition-colors">
          {article.title}
        </h3>

        {/* Description */}
        {article.description && (
          <p className="text-xs text-white/40 font-body leading-relaxed line-clamp-2">
            {truncate(article.description, 120)}
          </p>
        )}

        {/* CTA */}
        <div className="pt-1 flex items-center justify-between">
          <span className="text-xs font-body font-medium text-brand-400 group-hover:text-brand-300 flex items-center gap-1 transition-colors">
            <Zap size={11} fill="currentColor" />
            Generate Script
          </span>
          <a
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="text-white/20 hover:text-white/50 transition-colors"
            title="Read original article"
          >
            <ExternalLink size={12} />
          </a>
        </div>
      </div>
    </div>
  );
}
