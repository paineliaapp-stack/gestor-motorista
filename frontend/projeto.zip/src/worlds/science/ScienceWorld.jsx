import { useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScriptGenerator } from '../../hooks/useScriptGenerator';
import { ScriptModal } from '../../components/script/ScriptModal';

const PUBMED_BASE = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils';
const CATEGORIES = [
  { id:'neuroscience', label:'Neurociência', icon:'\u{1F9E0}', query:'neuroscience brain' },
  { id:'psychology', label:'Psicologia', icon:'\u{1F4AC}', query:'psychology mental health' },
  { id:'nutrition', label:'Nutrição', icon:'\u{1F96C}', query:'nutrition diet health' },
  { id:'fitness', label:'Exercício', icon:'\u{26A1}', query:'exercise fitness physical activity' },
  { id:'physio', label:'Fisioterapia', icon:'\u{1F9B4}', query:'physiotherapy rehabilitation' },
  { id:'medicine', label:'Medicina', icon:'\u{2695}\uFE0F', query:'clinical medicine treatment' },
];

async function searchPubMed(query) {
  const sRes = await fetch(PUBMED_BASE+'/esearch.fcgi?db=pubmed&term='+encodeURIComponent(query)+'&retmax=20&retmode=json&sort=relevance');
  const sData = await sRes.json();
  const ids = sData.esearchresult?.idlist || [];
  if (!ids.length) return [];
  const sumRes = await fetch(PUBMED_BASE+'/esummary.fcgi?db=pubmed&id='+ids.join(',')+'&retmode=json');
  const sumData = await sumRes.json();
  const result = sumData.result || {};
  return ids.map(id => {
    const a = result[id] || {};
    return { id:'pubmed_'+id, title:a.title||'', description:'Publicado: '+(a.source||'PubMed')+' ('+(a.pubdate||'').slice(0,4)+')', url:'https://pubmed.ncbi.nlm.nih.gov/'+id+'/', source:a.source||'PubMed', publishedAt:a.pubdate||'', viral_score:7, score_label:'High Potential', score_color:'orange', content_preview:a.title||'', image:null };
  }).filter(a => a.title);
}

export function ScienceWorld() {
  const navigate = useNavigate();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const generator = useScriptGenerator();
  const debounceRef = useRef(null);

  const fetchArticles = useCallback(async (query) => {
    setLoading(true);
    try { setArticles(await searchPubMed(query)); }
    catch(e) { setArticles([]); }
    finally { setLoading(false); }
  }, []);

  const accent = '#00e5b0';
  const glow = '0,229,176';

  return (
    <div style={{ minHeight:'100vh', background:'#020d0b', color:'#fff', fontFamily:'DM Sans, sans-serif' }}>
      <style dangerouslySetInnerHTML={{__html:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=DM+Sans:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap');
        *{box-sizing:border-box}
        input::placeholder{color:rgba(255,255,255,0.22)}
        input:focus{border-color:rgba(0,229,176,0.45)!important;outline:none}
        .sci-card:hover{background:rgba(0,229,176,0.07)!important;border-color:rgba(0,229,176,0.28)!important;transform:translateY(-2px)}
        .sci-cat:hover{background:rgba(0,229,176,0.12)!important;color:#00e5b0!important}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
      `}} />

      {/* Fundo lab: gradiente verde escuro com textura */}
      <div style={{ position:'fixed', inset:0, zIndex:0, pointerEvents:'none',
        background:'radial-gradient(ellipse at 20% 0%, rgba(0,80,60,0.35) 0%, transparent 50%), radial-gradient(ellipse at 80% 100%, rgba(0,120,90,0.2) 0%, transparent 50%), #020d0b' }} />
      <div style={{ position:'fixed', inset:0, zIndex:0, pointerEvents:'none', opacity:0.04,
        backgroundImage:'repeating-linear-gradient(0deg, rgba(0,229,176,0.5) 0px, transparent 1px, transparent 40px), repeating-linear-gradient(90deg, rgba(0,229,176,0.5) 0px, transparent 1px, transparent 40px)' }} />

      {/* Header */}
      <header style={{ position:'sticky', top:0, zIndex:50, height:56, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px', background:'rgba(2,13,11,0.85)', backdropFilter:'blur(32px)', WebkitBackdropFilter:'blur(32px)', borderBottom:'1px solid rgba(0,229,176,0.12)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          <button onClick={() => navigate('/')} style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.22em', color:'rgba(255,255,255,0.4)', background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:6, padding:0 }}>
            {String.fromCharCode(8592)} PORTAL
          </button>
          <span style={{ color:'rgba(255,255,255,0.1)' }}>|</span>
          <span style={{ fontFamily:'Playfair Display, serif', fontSize:18, fontWeight:700, color:accent, letterSpacing:'-0.5px' }}>Ciência</span>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:6, height:6, borderRadius:'50%', background:accent, boxShadow:'0 0 10px rgba('+glow+',0.8)' }} />
          <span style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.28em', color:'rgba(0,229,176,0.5)' }}>PUBMED</span>
        </div>
      </header>

      <div style={{ maxWidth:920, margin:'0 auto', padding:'40px 24px 80px', position:'relative', zIndex:5 }}>
        {/* Hero */}
        <div style={{ marginBottom:36 }}>
          <p style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.5em', color:'rgba(0,229,176,0.55)', marginBottom:10 }}>BASE DE DADOS CIENTÍFICA</p>
          <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:'clamp(34px,5.5vw,60px)', fontWeight:900, color:'#fff', margin:'0 0 8px', letterSpacing:'-2px', lineHeight:0.92 }}>
            Artigos{' '}<span style={{ fontStyle:'italic', color:accent }}>Científicos</span>
          </h1>
          <p style={{ fontFamily:'DM Sans', fontSize:13, color:'rgba(255,255,255,0.4)', margin:0, fontWeight:300 }}>Pesquise no PubMed e gere roteiros precisos e didáticos</p>
        </div>

        {/* Busca - glass */}
        <div style={{ position:'relative', marginBottom:20 }}>
          <input type="text" placeholder="Buscar artigos científicos..." value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              if (debounceRef.current) clearTimeout(debounceRef.current);
              debounceRef.current = setTimeout(() => { if (e.target.value.trim().length >= 3) fetchArticles(e.target.value.trim()); }, 600);
            }}
            style={{ width:'100%', background:'rgba(0,229,176,0.04)', backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)', border:'1px solid rgba(0,229,176,0.18)', borderRadius:12, padding:'14px 20px', fontSize:14, color:'white', fontFamily:'DM Sans', fontWeight:300 }} />
        </div>

        {/* Categorias - glass pills */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:36 }}>
          {CATEGORIES.map(cat => (
            <button key={cat.id} className="sci-cat" onClick={() => { setCategory(cat.id); setSearchQuery(''); fetchArticles(cat.query); }}
              style={{ padding:'7px 16px', borderRadius:20, border: category===cat.id ? '1px solid rgba('+glow+',0.65)' : '1px solid rgba(255,255,255,0.09)', background: category===cat.id ? 'rgba('+glow+',0.12)' : 'rgba(255,255,255,0.03)', backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)', color: category===cat.id ? accent : 'rgba(255,255,255,0.45)', fontFamily:'DM Sans', fontSize:12, fontWeight:500, cursor:'pointer', transition:'all 0.2s' }}>
              {cat.label}
            </button>
          ))}
        </div>

        {loading && (
          <div style={{ textAlign:'center', padding:'80px 0' }}>
            <div style={{ width:28, height:28, borderRadius:'50%', border:'2px solid rgba('+glow+',0.15)', borderTopColor:accent, animation:'spin 0.8s linear infinite', margin:'0 auto 16px' }} />
            <p style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.22em', color:'rgba(255,255,255,0.25)' }}>BUSCANDO NO PUBMED</p>
          </div>
        )}

        {!loading && articles.length === 0 && (
          <div style={{ textAlign:'center', padding:'80px 0', border:'1px dashed rgba(0,229,176,0.1)', borderRadius:16 }}>
            <p style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.3em', color:'rgba(255,255,255,0.2)', marginBottom:8 }}>AGUARDANDO PESQUISA</p>
            <p style={{ fontFamily:'DM Sans', fontSize:13, color:'rgba(255,255,255,0.22)', fontWeight:300 }}>Selecione uma categoria ou busque por tema</p>
          </div>
        )}

        {!loading && articles.length > 0 && (
          <div>
            <p style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.2em', color:'rgba(0,229,176,0.5)', marginBottom:20 }}>{articles.length} ARTIGOS ENCONTRADOS</p>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {articles.map((a, i) => <ScienceRow key={a.id} article={a} index={i} onGenerate={(art, opts) => { setSelected(art); generator.reset(); generator.generate(art, opts); }} />)}
            </div>
          </div>
        )}
      </div>

      {selected && <ScriptModal article={selected} generator={generator} onClose={() => setSelected(null)} onGenerate={(opts) => generator.generate(selected, opts)} />}
    </div>
  );
}

function ScienceRow({ article, index, onGenerate }) {
  const [showOpts, setShowOpts] = useState(false);
  const [platform, setPlatform] = useState('youtube_shorts');
  const [style, setStyle] = useState('educational');
  const accent = '#00e5b0';
  const glow = '0,229,176';
  return (
    <div className="sci-card" style={{ padding:'18px 20px', background:'rgba(0,229,176,0.03)', backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)', border:'1px solid rgba(0,229,176,0.1)', borderRadius:12, transition:'all 0.2s', animation:'fadeIn 0.35s ease both', animationDelay:(index*0.03)+'s' }}>
      <div style={{ display:'flex', gap:16, alignItems:'flex-start' }}>
        <span style={{ fontFamily:'Space Mono', fontSize:10, color:'rgba(0,229,176,0.35)', flexShrink:0, marginTop:3, minWidth:24 }}>{String(index+1).padStart(2,'0')}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <p style={{ fontFamily:'DM Sans', fontSize:14, color:'rgba(255,255,255,0.88)', margin:'0 0 6px', lineHeight:1.55, fontWeight:400 }}>{article.title}</p>
          <div style={{ display:'flex', gap:10 }}>
            <span style={{ fontFamily:'Space Mono', fontSize:9, color:'rgba(0,229,176,0.45)', letterSpacing:'0.1em' }}>{article.source}</span>
            {article.publishedAt && <span style={{ fontFamily:'Space Mono', fontSize:9, color:'rgba(255,255,255,0.2)' }}>{article.publishedAt.slice(0,4)}</span>}
          </div>
          {showOpts && (
            <div style={{ marginTop:14, display:'flex', gap:8, flexWrap:'wrap', alignItems:'center', padding:'12px 14px', background:'rgba(0,229,176,0.06)', border:'1px solid rgba(0,229,176,0.18)', borderRadius:10 }}>
              <select value={platform} onChange={e => setPlatform(e.target.value)} style={{ background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:6, padding:'5px 10px', color:'rgba(255,255,255,0.85)', fontSize:12, cursor:'pointer', fontFamily:'DM Sans' }}>
                <option value="tiktok">TikTok</option>
                <option value="youtube_shorts">YouTube Shorts</option>
                <option value="youtube_long">YouTube Longo</option>
              </select>
              <select value={style} onChange={e => setStyle(e.target.value)} style={{ background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:6, padding:'5px 10px', color:'rgba(255,255,255,0.85)', fontSize:12, cursor:'pointer', fontFamily:'DM Sans' }}>
                <option value="educational">Educacional</option>
                <option value="storytelling">Storytelling</option>
                <option value="dark_channel">Entretenimento</option>
                <option value="controversial">Debate</option>
              </select>
              <button onClick={() => onGenerate(article, { platform, style })} style={{ padding:'6px 18px', background:'rgba('+glow+',0.18)', border:'1px solid rgba('+glow+',0.45)', borderRadius:6, color:accent, fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.18em', cursor:'pointer', marginLeft:'auto' }}>
                GERAR {String.fromCharCode(8594)}
              </button>
            </div>
          )}
        </div>
        <button onClick={() => setShowOpts(!showOpts)} style={{ padding:'7px 14px', border: showOpts ? '1px solid rgba('+glow+',0.5)' : '1px solid rgba(255,255,255,0.1)', borderRadius:8, background: showOpts ? 'rgba('+glow+',0.10)' : 'rgba(255,255,255,0.04)', backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)', color: showOpts ? accent : 'rgba(255,255,255,0.4)', fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.12em', cursor:'pointer', flexShrink:0, transition:'all 0.2s' }}>
          {showOpts ? 'FECHAR' : 'USAR'}
        </button>
      </div>
    </div>
  );
}
