import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

if (typeof document !== 'undefined' && !document.getElementById('vn-fonts')) {
  const l = document.createElement('link');
  l.id = 'vn-fonts'; l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=DM+Sans:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap';
  document.head.appendChild(l);
}

export function SpaceBackground() {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let W = window.innerWidth, H = window.innerHeight;
    canvas.width = W; canvas.height = H;
    const stars = Array.from({ length: 200 }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.2 + 0.1,
      alpha: Math.random() * 0.6 + 0.1,
      speed: Math.random() * 0.015 + 0.003,
      phase: Math.random() * Math.PI * 2,
    }));
    const orbs = [
      { x: W*0.12, y: H*0.18, r: W*0.38, color:'40,60,200', alpha:0.07, dx:0.09, dy:0.05 },
      { x: W*0.88, y: H*0.72, r: W*0.30, color:'100,20,160', alpha:0.05, dx:-0.07, dy:0.08 },
      { x: W*0.5, y: H*0.92, r: W*0.25, color:'0,140,170', alpha:0.04, dx:0.04, dy:-0.06 },
    ];
    let frame = 0, animId;
    const draw = () => {
      animId = requestAnimationFrame(draw); frame++;
      ctx.clearRect(0, 0, W, H);
      orbs.forEach(o => {
        o.x += o.dx; o.y += o.dy;
        if (o.x < -o.r) o.x = W+o.r; if (o.x > W+o.r) o.x = -o.r;
        if (o.y < -o.r) o.y = H+o.r; if (o.y > H+o.r) o.y = -o.r;
        const g = ctx.createRadialGradient(o.x,o.y,0,o.x,o.y,o.r);
        g.addColorStop(0,'rgba('+o.color+','+o.alpha+')');
        g.addColorStop(1,'rgba('+o.color+',0)');
        ctx.fillStyle=g; ctx.beginPath(); ctx.arc(o.x,o.y,o.r,0,Math.PI*2); ctx.fill();
      });
      stars.forEach(s => {
        const t = Math.sin(frame*s.speed+s.phase)*0.3+0.7;
        ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2);
        ctx.fillStyle='rgba(255,255,255,'+(s.alpha*t)+')'; ctx.fill();
      });
    };
    draw();
    const onResize = () => { W=window.innerWidth; H=window.innerHeight; canvas.width=W; canvas.height=H; };
    window.addEventListener('resize', onResize);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', onResize); };
  }, []);
  return <canvas ref={canvasRef} style={{ position:'fixed',inset:0,zIndex:0,pointerEvents:'none' }} />;
}

const WORLDS = [
  { id:'news', path:'/news', num:'01', tag:'AO VIVO', label:'Not\u00edcias', accent:'#5b9bff', glow:'91,155,255', desc:'Not\u00edcias virais em roteiros para TikTok, Shorts e YouTube' },
  { id:'science', path:'/science', num:'02', tag:'PUBMED', label:'Ci\u00eancia', accent:'#00e5b0', glow:'0,229,176', desc:'Artigos cient\u00edficos do PubMed em conte\u00fado acess\u00edvel e viral' },
  { id:'books', path:'/books', num:'03', tag:'BIBLIOTECA', label:'Livros', accent:'#ffbe4d', glow:'255,190,77', desc:'Insights de livros transformados em roteiros que ensinam e engajam' },
];

function WorldCard({ world }) {
  const navigate = useNavigate();
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={() => navigate(world.path)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position:'relative', borderRadius:20, overflow:'hidden', cursor:'pointer',
        padding:'36px 32px 32px', minHeight:270,
        background: hovered ? 'rgba(255,255,255,0.10)' : 'rgba(255,255,255,0.05)',
        backdropFilter:'blur(40px) saturate(200%)',
        WebkitBackdropFilter:'blur(40px) saturate(200%)',
        border:'1px solid '+(hovered ? 'rgba('+world.glow+',0.55)' : 'rgba(255,255,255,0.12)'),
        transform: hovered ? 'translateY(-8px) scale(1.015)' : 'translateY(0) scale(1)',
        transition:'all 0.4s cubic-bezier(0.34,1.56,0.64,1)',
        boxShadow: hovered
          ? '0 0 70px 12px rgba('+world.glow+',0.18), 0 30px 70px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.20)'
          : '0 8px 40px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)',
      }}
    >
      <div style={{
        position:'absolute', inset:0, borderRadius:20, pointerEvents:'none',
        background:'radial-gradient(ellipse at 50% 115%, rgba('+world.glow+','+(hovered?0.20:0.04)+') 0%, transparent 65%)',
        transition:'all 0.5s ease',
      }} />
      <div style={{
        position:'absolute', top:0, left:'10%', right:'10%', height:1,
        background:'linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)',
        pointerEvents:'none',
      }} />
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28, position:'relative', zIndex:2 }}>
        <span style={{ fontFamily:'Space Mono, monospace', fontSize:11, color:'rgba(255,255,255,0.45)', letterSpacing:'0.12em' }}>{world.num}</span>
        <span style={{ fontFamily:'DM Sans, sans-serif', fontSize:9, letterSpacing:'0.22em', color:world.accent, border:'1px solid rgba('+world.glow+',0.45)', background:'rgba('+world.glow+',0.10)', padding:'4px 12px', borderRadius:4, fontWeight:500 }}>{world.tag}</span>
      </div>
      <h2 style={{ fontFamily:'Playfair Display, serif', fontSize:46, fontWeight:900, color: hovered ? world.accent : '#ffffff', margin:'0 0 14px', lineHeight:0.95, position:'relative', zIndex:2, transition:'color 0.3s', letterSpacing:'-1px' }}>{world.label}</h2>
      <p style={{ fontFamily:'DM Sans, sans-serif', fontSize:14, lineHeight:1.65, color:'rgba(255,255,255,0.62)', margin:'0 0 30px', position:'relative', zIndex:2, fontWeight:300 }}>{world.desc}</p>
      <div style={{ display:'flex', alignItems:'center', gap:8, fontFamily:'Space Mono, monospace', fontSize:9, letterSpacing:'0.28em', color: hovered ? world.accent : 'rgba(255,255,255,0.35)', transition:'color 0.3s', position:'relative', zIndex:2 }}>
        <span>ACESSAR</span>
        <span style={{ display:'inline-block', transform: hovered ? 'translateX(6px)' : 'none', transition:'transform 0.3s' }}>{String.fromCharCode(8594)}</span>
      </div>
    </div>
  );
}

export function WorldPortal() {
  return (
    <div style={{ minHeight:'100vh', background:'radial-gradient(ellipse at 40% 10%, #0e1535 0%, #060810 55%, #020308 100%)', color:'#fff', position:'relative', overflow:'hidden' }}>
      <SpaceBackground />
      <header style={{ position:'relative', zIndex:10, padding:'0 32px', height:58, display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid rgba(255,255,255,0.07)', background:'rgba(5,6,18,0.65)', backdropFilter:'blur(28px)', WebkitBackdropFilter:'blur(28px)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:7, height:7, borderRadius:'50%', background:'#00e5b0', boxShadow:'0 0 12px rgba(0,229,176,0.9)', animation:'blink 2.8s ease-in-out infinite' }} />
          <span style={{ fontFamily:'Space Mono, monospace', fontSize:10, letterSpacing:'0.42em', color:'rgba(255,255,255,0.85)' }}>VIRALNEWS AI</span>
        </div>
        <span style={{ fontFamily:'DM Sans, sans-serif', fontSize:11, letterSpacing:'0.18em', color:'rgba(255,255,255,0.35)', fontWeight:300 }}>GERADOR DE ROTEIROS COM IA</span>
      </header>
      <div style={{ position:'relative', zIndex:5, textAlign:'center', padding:'72px 24px 52px' }}>
        <p style={{ fontFamily:'Space Mono, monospace', fontSize:9, letterSpacing:'0.5em', color:'rgba(255,255,255,0.45)', marginBottom:18 }}>GERADOR DE ROTEIROS COM IA</p>
        <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:'clamp(58px, 10vw, 104px)', fontWeight:900, letterSpacing:'-4px', margin:'0 0 16px', lineHeight:0.9 }}>
          <span style={{ color:'#ffffff', fontStyle:'italic' }}>Viral</span>
          <span style={{ fontWeight:900, color:'transparent', WebkitTextStroke:'2.5px rgba(255,255,255,0.9)', fontStyle:'normal' }}>News</span>
        </h1>
        <p style={{ fontFamily:'DM Sans, sans-serif', fontSize:13, letterSpacing:'0.22em', color:'rgba(255,255,255,0.5)', margin:0, fontWeight:300 }}>SELECIONE SEU UNIVERSO DE CONTEÚDO</p>
      </div>
      <div style={{ position:'relative', zIndex:5, maxWidth:1100, margin:'0 auto', padding:'0 24px 80px', display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(300px, 1fr))', gap:20 }}>
        {WORLDS.map((w) => <WorldCard key={w.id} world={w} />)}
      </div>
      <div style={{ position:'relative', zIndex:5, textAlign:'center', paddingBottom:32, fontFamily:'Space Mono, monospace', fontSize:8, letterSpacing:'0.35em', color:'rgba(255,255,255,0.18)' }}>VIRALNEWS AI V1.0 · POWERED BY GROQ · PUBMED · NEWSAPI</div>
      <style dangerouslySetInnerHTML={{__html:'@keyframes blink{0%,100%{opacity:1}50%{opacity:0.2}}*{box-sizing:border-box}'}} />
    </div>
  );
}
