import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScriptGenerator } from '../../hooks/useScriptGenerator';

if (typeof document !== 'undefined' && !document.getElementById('bw-fonts')) {
  const l = document.createElement('link');
  l.id = 'bw-fonts'; l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,700&family=DM+Sans:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap';
  document.head.appendChild(l);
}

const BOOKS = [
  { title: 'Atomic Habits', author: 'James Clear', cat: 'Produtividade', score: 9.1, cover: 'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg' },
  { title: 'O Poder do Hábito', author: 'Charles Duhigg', cat: 'Produtividade', score: 8.7, cover: 'https://covers.openlibrary.org/b/isbn/9780812981605-L.jpg' },
  { title: 'Sapiens', author: 'Yuval Noah Harari', cat: 'História', score: 9.4, cover: 'https://covers.openlibrary.org/b/isbn/9780062316110-L.jpg' },
  { title: 'A Sutil Arte de Ligar o Foda-se', author: 'Mark Manson', cat: 'Autoajuda', score: 8.9, cover: 'https://covers.openlibrary.org/b/isbn/9780062457714-L.jpg' },
  { title: 'Mindset', author: 'Carol Dweck', cat: 'Psicologia', score: 8.6, cover: 'https://covers.openlibrary.org/b/isbn/9780345472328-L.jpg' },
  { title: 'O Milagre da Manhã', author: 'Hal Elrod', cat: 'Produtividade', score: 7.8, cover: 'https://covers.openlibrary.org/b/isbn/9781942589891-L.jpg' },
  { title: 'Ansiedade', author: 'Augusto Cury', cat: 'Saúde Mental', score: 7.5, cover: 'https://covers.openlibrary.org/b/isbn/9788576849704-L.jpg' },
  { title: 'Os 7 Hábitos', author: 'Stephen Covey', cat: 'Liderança', score: 8.8, cover: 'https://covers.openlibrary.org/b/isbn/9780743269513-L.jpg' },
  { title: 'Rápido e Devagar', author: 'Daniel Kahneman', cat: 'Psicologia', score: 9.0, cover: 'https://covers.openlibrary.org/b/isbn/9780374533557-L.jpg' },
  { title: 'O Homem em Busca de Sentido', author: 'Viktor Frankl', cat: 'Filosofia', score: 9.3, cover: 'https://covers.openlibrary.org/b/isbn/9780807014271-L.jpg' },
  { title: 'Pai Rico Pai Pobre', author: 'Robert Kiyosaki', cat: 'Finanças', score: 8.5, cover: 'https://covers.openlibrary.org/b/isbn/9781612680194-L.jpg' },
  { title: 'Como Fazer Amigos e Influenciar Pessoas', author: 'Dale Carnegie', cat: 'Relacionamentos', score: 8.4, cover: 'https://covers.openlibrary.org/b/isbn/9780671027032-L.jpg' },
  { title: 'O Poder do Agora', author: 'Eckhart Tolle', cat: 'Filosofia', score: 8.7, cover: 'https://covers.openlibrary.org/b/isbn/9781577314806-L.jpg' },
  { title: 'A Coragem de Ser Imperfeito', author: 'Brené Brown', cat: 'Autoajuda', score: 8.3, cover: 'https://covers.openlibrary.org/b/isbn/9781592858491-L.jpg' },
  { title: 'A Arte da Guerra', author: 'Sun Tzu', cat: 'Estratégia', score: 8.9, cover: 'https://covers.openlibrary.org/b/isbn/9781590302255-L.jpg' },
  { title: 'O Pequeno Príncipe', author: 'Antoine de Saint-Exupéry', cat: 'Literatura', score: 9.2, cover: 'https://covers.openlibrary.org/b/isbn/9780156012195-L.jpg' },
  { title: 'Dom Casmurro', author: 'Machado de Assis', cat: 'Literatura', score: 8.8, cover: 'https://covers.openlibrary.org/b/isbn/9788535902778-L.jpg' },
  { title: 'O Segredo', author: 'Rhonda Byrne', cat: 'Autoajuda', score: 7.4, cover: 'https://covers.openlibrary.org/b/isbn/9781582701707-L.jpg' },
  { title: 'Hábitos Atômicos', author: 'James Clear', cat: 'Produtividade', score: 9.1, cover: 'https://covers.openlibrary.org/b/isbn/9780735211292-L.jpg' },
  { title: 'O Monge e o Executivo', author: 'James Hunter', cat: 'Liderança', score: 8.0, cover: 'https://covers.openlibrary.org/b/isbn/9781476794839-L.jpg' },
];

const CATS = ['Todos', 'Produtividade', 'Psicologia', 'Finanças', 'Autoajuda', 'Filosofia', 'Literatura', 'Liderança', 'Saúde Mental', 'História', 'Estratégia', 'Relacionamentos'];
const PLATFORMS = [{ value: 'tiktok', label: 'TikTok' }, { value: 'youtube_shorts', label: 'YouTube Shorts' }, { value: 'youtube_long', label: 'YouTube Longo' }];
const STYLES = [{ value: 'educational', label: 'Educacional' }, { value: 'storytelling', label: 'Storytelling' }, { value: 'dark_channel', label: 'Entretenimento' }, { value: 'controversial', label: 'Debate' }];

const PALETTES = [
  { bg: '#1a1200', accent: '#c8890f' },
  { bg: '#0a0e1a', accent: '#4a7ec0' },
  { bg: '#120a1e', accent: '#8a5ac0' },
  { bg: '#081410', accent: '#4a9a5a' },
  { bg: '#180a0a', accent: '#c04a4a' },
];

const coverCache = {};

async function fetchCover(title, author) {
  const key = `${title}__${author}`;
  if (coverCache[key] !== undefined) return coverCache[key];
  try {
    const q = encodeURIComponent(`intitle:"${title}" inauthor:"${author}"`);
    const res = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${q}&maxResults=3&fields=items(volumeInfo/imageLinks,volumeInfo/title)`);
    const data = await res.json();
    const items = data?.items || [];
    let links = null;
    for (const item of items) {
      const t = (item.volumeInfo?.title || '').toLowerCase();
      if (t.includes(title.toLowerCase().slice(0, 6))) {
        links = item.volumeInfo?.imageLinks;
        break;
      }
    }
    if (!links) links = items[0]?.volumeInfo?.imageLinks;
    const url = links?.thumbnail || links?.smallThumbnail || null;
    const hq = url ? url.replace('zoom=1', 'zoom=3').replace('&edge=curl', '').replace('http://', 'https://') : null;
    coverCache[key] = hq;
    return hq;
  } catch {
    coverCache[key] = null;
    return null;
  }
}

function useIsMobile() {
  const [mobile, setMobile] = useState(window.innerWidth < 640);
  useEffect(() => {
    const fn = () => setMobile(window.innerWidth < 640);
    window.addEventListener('resize', fn);
    return () => window.removeEventListener('resize', fn);
  }, []);
  return mobile;
}

function AnimatedCounter({ target }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const duration = 1800;
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    const timer = setTimeout(() => requestAnimationFrame(tick), 400);
    return () => clearTimeout(timer);
  }, [target]);
  return <>{count.toLocaleString('pt-BR')}</>;
}

function BookCover({ book, hovered, size = 'normal' }) {
  const [cover, setCover] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const pal = PALETTES[book.title.length % PALETTES.length];
  const initials = book.title.split(' ').filter(w => w.length > 2).slice(0, 2).map(w => w[0]).join('').toUpperCase();

  useEffect(() => {
    let cancelled = false;
    fetchCover(book.title, book.author).then(url => {
      if (!cancelled) { setCover(url); if (!url) setFailed(true); }
    });
    return () => { cancelled = true; };
  }, [book.title, book.author]);

  const fontSize = size === 'small' ? 20 : 34;

  return (
    <div style={{ width: '100%', aspectRatio: '2/3', background: pal.bg, position: 'relative', overflow: 'hidden', flexShrink: 0 }}>
      {/* Shimmer enquanto carrega */}
      {!loaded && !failed && (
        <div style={{
          position: 'absolute', inset: 0,
          background: `linear-gradient(90deg, ${pal.bg} 25%, rgba(255,255,255,0.04) 50%, ${pal.bg} 75%)`,
          backgroundSize: '200% 100%',
          animation: 'bwShimmer 1.5s ease infinite',
        }} />
      )}
      {cover && !failed && (
        <img
          src={cover}
          alt={book.title}
          onLoad={() => setLoaded(true)}
          onError={() => { setFailed(true); }}
          style={{
            width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center',
            display: 'block', opacity: loaded ? 1 : 0,
            transition: 'opacity 0.5s ease, transform 0.4s ease',
            transform: hovered ? 'scale(1.04)' : 'scale(1)',
          }}
        />
      )}
      {(failed || (!cover && loaded)) && (
        <div style={{
          position: 'absolute', inset: 0,
          background: `linear-gradient(155deg, ${pal.bg} 0%, #000 100%)`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 20,
        }}>
          <div style={{ width: 1, height: 28, background: `linear-gradient(180deg, transparent, ${pal.accent}66, transparent)` }} />
          <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize, fontWeight: 700, color: pal.accent, letterSpacing: 3, lineHeight: 1 }}>{initials}</span>
          <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 6, letterSpacing: '0.2em', color: `${pal.accent}66`, textAlign: 'center', lineHeight: 1.7, maxWidth: 90 }}>{book.title.toUpperCase()}</span>
        </div>
      )}
      <div style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: 5, background: 'linear-gradient(90deg, rgba(0,0,0,0.45) 0%, transparent 100%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 50, background: 'linear-gradient(0deg, rgba(0,0,0,0.65) 0%, transparent 100%)', pointerEvents: 'none' }} />
    </div>
  );
}

function BookCard({ book, index, onClick, isMobile }) {
  const [hovered, setHovered] = useState(false);
  const [visible, setVisible] = useState(false);
  const ref = useRef(null);
  const scoreColor = book.score >= 9 ? '#00e5b0' : book.score >= 8 ? '#ffbe4d' : 'rgba(255,255,255,0.5)';
  const isTrending = book.score >= 9;

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.05 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      onClick={() => onClick(book)}
      onMouseEnter={() => !isMobile && setHovered(true)}
      onMouseLeave={() => !isMobile && setHovered(false)}
      style={{
        borderRadius: 12, overflow: 'hidden', cursor: 'pointer',
        border: `1px solid ${hovered ? 'rgba(255,190,77,0.2)' : 'rgba(255,255,255,0.055)'}`,
        background: hovered ? 'rgba(255,255,255,0.038)' : 'rgba(255,255,255,0.016)',
        transform: visible ? (hovered ? 'translateY(-6px)' : 'translateY(0)') : 'translateY(24px)',
        opacity: visible ? 1 : 0,
        filter: visible ? 'blur(0px)' : 'blur(4px)',
        boxShadow: hovered ? '0 24px 50px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,190,77,0.07)' : '0 2px 8px rgba(0,0,0,0.3)',
        transition: `transform 0.32s cubic-bezier(0.4,0,0.2,1), box-shadow 0.32s ease, border-color 0.2s, background 0.2s, opacity 0.55s ease ${index * 0.05}s, filter 0.55s ease ${index * 0.05}s`,
        position: 'relative',
      }}
    >
      <BookCover book={book} hovered={hovered} />

      <div style={{
        position: 'absolute', top: 8, right: 8,
        background: 'rgba(0,0,0,0.78)', backdropFilter: 'blur(16px)',
        border: '1px solid rgba(255,255,255,0.08)', borderRadius: 20,
        padding: '3px 8px', display: 'flex', alignItems: 'center', gap: 4,
      }}>
        <div style={{
          width: 5, height: 5, borderRadius: '50%', background: scoreColor,
          boxShadow: isTrending ? `0 0 6px ${scoreColor}` : 'none',
          animation: isTrending ? 'bwPulse 2s ease infinite' : 'none',
        }} />
        <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 9, color: scoreColor, fontWeight: 700 }}>{book.score}</span>
      </div>

      {isTrending && (
        <div style={{
          position: 'absolute', top: 8, left: 8,
          background: 'rgba(0,0,0,0.78)', backdropFilter: 'blur(16px)',
          border: '1px solid rgba(255,190,77,0.22)', borderRadius: 4,
          padding: '2px 6px',
        }}>
          <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 6, letterSpacing: '0.18em', color: '#ffbe4d' }}>TRENDING</span>
        </div>
      )}

      <div style={{ padding: isMobile ? '10px 11px 12px' : '12px 14px 15px' }}>
        <p style={{
          fontFamily: 'Cormorant Garamond, serif', fontSize: isMobile ? 14 : 16, fontWeight: 600,
          color: hovered ? '#fff' : 'rgba(255,255,255,0.92)',
          margin: '0 0 2px', lineHeight: 1.2, letterSpacing: '-0.2px', transition: 'color 0.2s',
        }}>{book.title}</p>
        <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: isMobile ? 10 : 11, color: 'rgba(255,255,255,0.45)', margin: '0 0 10px', fontWeight: 300 }}>{book.author}</p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{
            fontFamily: 'Space Mono, monospace', fontSize: 6, letterSpacing: '0.12em',
            color: 'rgba(255,190,77,0.6)', border: '1px solid rgba(255,190,77,0.16)',
            padding: '2px 6px', borderRadius: 4,
          }}>{book.cat.toUpperCase()}</span>
          {!isMobile && (
            <span style={{
              fontFamily: 'DM Sans, sans-serif', fontSize: 10,
              color: hovered ? 'rgba(255,190,77,0.85)' : 'rgba(255,255,255,0.25)',
              transition: 'color 0.2s',
            }}>roteirizar →</span>
          )}
        </div>
      </div>
    </div>
  );
}

function BooksModal({ book, onClose, isMobile }) {
  const generator = useScriptGenerator();
  const [platform, setPlatform] = useState('youtube_shorts');
  const [style, setStyle] = useState('educational');
  const outputRef = useRef(null);

  const buildArticle = () => ({
    id: 'book_' + Date.now(),
    title: `${book.title} — ${book.author}`,
    description: `Livro: ${book.title} de ${book.author}`,
    url: '', source: 'Livro', publishedAt: '',
    viral_score: Math.round(book.score),
    content_preview: `REGRA ABSOLUTA: Este roteiro deve ser baseado EXCLUSIVAMENTE no livro "${book.title}" de ${book.author}. Nunca invente fatos não presentes no livro.`,
    image: null,
  });

  useEffect(() => {
    generator.setPlatform(platform);
    generator.setStyle(style);
    setTimeout(() => generator.generate(buildArticle(), 1), 80);
  }, []);

  useEffect(() => {
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight;
  }, [generator.script]);

  const handleRegenerate = () => {
    generator.setPlatform(platform);
    generator.setStyle(style);
    generator.reset();
    setTimeout(() => generator.generate(buildArticle(), 1), 0);
  };

  const wordCount = generator.script ? generator.script.split(/\s+/).filter(Boolean).length : 0;
  const readTime = Math.ceil(wordCount / 150);

  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{
        position: 'fixed', inset: 0, zIndex: 200,
        background: 'rgba(4,3,0,0.92)',
        backdropFilter: 'blur(28px)', WebkitBackdropFilter: 'blur(28px)',
        display: 'flex', alignItems: isMobile ? 'flex-end' : 'center', justifyContent: 'center',
        padding: isMobile ? 0 : 24, animation: 'bwFadeIn 0.2s ease',
      }}
    >
      <div style={{
        width: '100%', maxWidth: isMobile ? '100%' : 880,
        maxHeight: isMobile ? '92vh' : '90vh',
        background: '#0d0900', border: '1px solid rgba(255,190,77,0.12)',
        borderRadius: isMobile ? '20px 20px 0 0' : 20,
        overflow: 'hidden', display: 'flex', flexDirection: 'column',
        animation: isMobile ? 'bwSlideUp 0.3s cubic-bezier(0.34,1.1,0.64,1)' : 'bwSlideUp 0.32s cubic-bezier(0.34,1.1,0.64,1)',
        boxShadow: '0 48px 120px rgba(0,0,0,0.85)',
      }}>
        {/* Header */}
        <div style={{
          padding: isMobile ? '16px 18px' : '20px 28px',
          borderBottom: '1px solid rgba(255,190,77,0.07)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          background: 'rgba(255,190,77,0.02)', flexShrink: 0,
        }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <div style={{ width: isMobile ? 36 : 48, height: isMobile ? 52 : 68, borderRadius: 6, overflow: 'hidden', flexShrink: 0, border: '1px solid rgba(255,190,77,0.1)', background: '#1a1200' }}>
              <BookCover book={book} hovered={false} size="small" />
            </div>
            <div>
              <p style={{ fontFamily: 'Space Mono, monospace', fontSize: 7, letterSpacing: '0.3em', color: 'rgba(255,190,77,0.38)', margin: '0 0 4px' }}>ROTEIRO — BIBLIOTECA</p>
              <h2 style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: isMobile ? 17 : 22, fontWeight: 700, color: '#fff', margin: '0 0 2px', letterSpacing: '-0.3px' }}>{book.title}</h2>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.45)', margin: 0, fontWeight: 300 }}>{book.author}</p>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {!isMobile && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#00e5b0', boxShadow: '0 0 6px #00e5b0' }} />
                <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 9, color: '#00e5b0' }}>{book.score}/10</span>
              </div>
            )}
            <button onClick={onClose} style={{
              background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)',
              color: 'rgba(255,255,255,0.45)', borderRadius: 8, width: 30, height: 30,
              cursor: 'pointer', fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>✕</button>
          </div>
        </div>

        {/* Controls */}
        <div style={{
          padding: isMobile ? '10px 16px' : '12px 28px',
          borderBottom: '1px solid rgba(255,255,255,0.035)',
          display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0,
        }}>
          {[{ v: platform, fn: setPlatform, opts: PLATFORMS }, { v: style, fn: setStyle, opts: STYLES }].map((s, i) => (
            <div key={i} style={{ position: 'relative' }}>
              <select value={s.v} onChange={e => s.fn(e.target.value)} style={{
                fontFamily: 'DM Sans, sans-serif', fontSize: 11,
                color: 'rgba(255,255,255,0.55)', background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,190,77,0.1)', borderRadius: 8,
                padding: '6px 26px 6px 11px', cursor: 'pointer', appearance: 'none',
              }}>
                {s.opts.map(o => <option key={o.value} value={o.value} style={{ background: '#0d0900' }}>{o.label}</option>)}
              </select>
              <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 8, color: 'rgba(255,255,255,0.25)', pointerEvents: 'none' }}>▾</span>
            </div>
          ))}
          <button onClick={handleRegenerate} disabled={generator.loading} style={{
            fontFamily: 'Space Mono, monospace', fontSize: 8, letterSpacing: '0.18em',
            color: generator.loading ? 'rgba(255,190,77,0.3)' : '#ffbe4d',
            background: 'rgba(255,190,77,0.05)', border: '1px solid rgba(255,190,77,0.15)',
            borderRadius: 8, padding: '7px 14px', cursor: generator.loading ? 'not-allowed' : 'pointer',
          }}>{generator.loading ? 'GERANDO...' : '↺ REGERAR'}</button>
          {generator.script && !generator.loading && (
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 10, alignItems: 'center' }}>
              {!isMobile && <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 8, color: 'rgba(255,255,255,0.22)', letterSpacing: '0.12em' }}>{wordCount} palavras · ~{readTime} min</span>}
              <button onClick={() => navigator.clipboard?.writeText(generator.script)} style={{
                fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,190,77,0.75)',
                background: 'transparent', border: '1px solid rgba(255,190,77,0.15)',
                borderRadius: 7, padding: '5px 13px', cursor: 'pointer',
              }}>Copiar</button>
            </div>
          )}
        </div>

        {/* Output */}
        <div ref={outputRef} style={{ flex: 1, overflowY: 'auto', padding: isMobile ? '20px 18px' : '28px 32px', scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,190,77,0.1) transparent' }}>
          {generator.loading && !generator.script && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '50px 0', gap: 16 }}>
              <div style={{ width: 48, height: 48, borderRadius: 14, background: 'rgba(255,190,77,0.07)', border: '1px solid rgba(255,190,77,0.14)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, animation: 'bwPulse 1.6s ease infinite' }}>📖</div>
              <div style={{ textAlign: 'center' }}>
                <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 19, color: 'rgba(255,255,255,0.5)', margin: '0 0 6px', fontStyle: 'italic' }}>Criando seu roteiro...</p>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.28)', margin: 0, fontWeight: 300 }}>A IA está analisando o livro e gerando conteúdo viral</p>
              </div>
            </div>
          )}
          {generator.error && (
            <div style={{ padding: '16px 20px', background: 'rgba(180,40,40,0.08)', border: '1px solid rgba(180,40,40,0.15)', borderRadius: 10 }}>
              <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,110,110,0.85)', margin: 0 }}>{generator.error}</p>
            </div>
          )}
          {generator.script && (
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: isMobile ? 13 : 14, color: 'rgba(255,255,255,0.82)', lineHeight: 1.9, fontWeight: 300, whiteSpace: 'pre-wrap', letterSpacing: '0.01em' }}>
              {generator.script}
              {generator.loading && (
                <span style={{ display: 'inline-block', width: 2, height: 14, background: '#ffbe4d', marginLeft: 3, animation: 'bwPulse 0.8s ease infinite', verticalAlign: 'text-bottom' }} />
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function BooksWorld() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('Todos');
  const [platform, setPlatform] = useState('youtube_shorts');
  const [style, setStyle] = useState('educational');
  const [selectedBook, setSelectedBook] = useState(null);
  const filtersRef = useRef(null);

  const filtered = BOOKS.filter(b => {
    const s = search.toLowerCase();
    return (!search || b.title.toLowerCase().includes(s) || b.author.toLowerCase().includes(s))
      && (cat === 'Todos' || b.cat === cat);
  });

  const cols = isMobile ? 2 : 4;
  const rows = [];
  for (let i = 0; i < filtered.length; i += cols) rows.push(filtered.slice(i, i + cols));

  return (
    <div style={{ minHeight: '100vh', background: '#080600', color: '#fff', fontFamily: 'DM Sans, sans-serif', overflowX: 'hidden' }}>
      <style dangerouslySetInnerHTML={{ __html: `
        *, *::before, *::after { box-sizing: border-box; }
        @keyframes bwFadeIn { from { opacity:0; } to { opacity:1; } }
        @keyframes bwSlideUp { from { opacity:0; transform:translateY(40px) scale(0.98); } to { opacity:1; transform:translateY(0) scale(1); } }
        @keyframes bwPulse { 0%,100% { opacity:1; } 50% { opacity:0.35; } }
        @keyframes bwShimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
        input::placeholder { color: rgba(255,255,255,0.18); }
        input:focus { outline: none; border-color: rgba(255,190,77,0.28) !important; box-shadow: 0 0 0 3px rgba(255,190,77,0.05); }
        select { appearance: none; -webkit-appearance: none; }
        ::-webkit-scrollbar { width: 3px; height: 3px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,190,77,0.1); border-radius: 2px; }
        .bw-cat-scroll { display: flex; gap: 6px; overflow-x: auto; scrollbar-width: none; -ms-overflow-style: none; padding-bottom: 2px; }
        .bw-cat-scroll::-webkit-scrollbar { display: none; }
        .bw-cat { white-space: nowrap; flex-shrink: 0; }
        .bw-cat:hover { border-color: rgba(255,190,77,0.22) !important; color: rgba(255,255,255,0.62) !important; }
      ` }} />

      <div style={{ position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none', background: 'radial-gradient(ellipse at 12% 0%, rgba(110,68,0,0.22) 0%, transparent 50%), radial-gradient(ellipse at 88% 100%, rgba(70,44,0,0.14) 0%, transparent 50%)' }} />

      {/* Header */}
      <header style={{
        position: 'sticky', top: 0, zIndex: 100,
        height: 52, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: isMobile ? '0 16px' : '0 36px',
        background: 'rgba(8,6,0,0.94)',
        backdropFilter: 'blur(40px)', WebkitBackdropFilter: 'blur(40px)',
        borderBottom: '1px solid rgba(255,255,255,0.04)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <button onClick={() => navigate('/')} style={{
            fontFamily: 'Space Mono, monospace', fontSize: 8, letterSpacing: '0.25em',
            color: 'rgba(255,255,255,0.3)', background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          }}>← PORTAL</button>
          <div style={{ width: 1, height: 14, background: 'rgba(255,255,255,0.06)' }} />
          <span style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 20, fontWeight: 600, color: '#ffbe4d', fontStyle: 'italic', letterSpacing: '-0.5px' }}>Livros</span>
        </div>
        {!isMobile && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {[{ v: platform, fn: setPlatform, opts: PLATFORMS }, { v: style, fn: setStyle, opts: STYLES }].map((s, i) => (
              <div key={i} style={{ position: 'relative' }}>
                <select value={s.v} onChange={e => s.fn(e.target.value)} style={{
                  fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.5)',
                  background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)',
                  borderRadius: 8, padding: '6px 26px 6px 12px', cursor: 'pointer',
                }}>
                  {s.opts.map(o => <option key={o.value} value={o.value} style={{ background: '#0d0900' }}>{o.label}</option>)}
                </select>
                <span style={{ position: 'absolute', right: 9, top: '50%', transform: 'translateY(-50%)', fontSize: 8, color: 'rgba(255,255,255,0.26)', pointerEvents: 'none' }}>▾</span>
              </div>
            ))}
            <div style={{ width: 1, height: 14, background: 'rgba(255,255,255,0.06)', marginLeft: 4 }} />
            <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 8, letterSpacing: '0.3em', color: 'rgba(255,190,77,0.22)' }}>BIBLIOTECA</span>
          </div>
        )}
      </header>

      <main style={{ maxWidth: 1280, margin: '0 auto', padding: isMobile ? '40px 16px 80px' : '64px 36px 120px', position: 'relative', zIndex: 5 }}>

        {/* Hero */}
        <div style={{ marginBottom: isMobile ? 40 : 64, animation: 'bwFadeIn 0.7s ease both' }}>
          <p style={{ fontFamily: 'Space Mono, monospace', fontSize: 7, letterSpacing: '0.55em', color: 'rgba(255,190,77,0.4)', marginBottom: 18 }}>GERADOR DE ROTEIROS</p>
          <h1 style={{
            fontFamily: 'Cormorant Garamond, serif',
            fontSize: isMobile ? 'clamp(38px,11vw,54px)' : 'clamp(54px,7.5vw,100px)',
            fontWeight: 700, lineHeight: 0.9, letterSpacing: isMobile ? '-2px' : '-4px', margin: '0 0 22px',
          }}>
            Os livros que estão{' '}
            <em style={{ color: '#ffbe4d', fontStyle: 'italic' }}>dominando</em>{' '}
            o TikTok.
          </h1>
          <div style={{ display: 'flex', flexDirection: isMobile ? 'column' : 'row', alignItems: isMobile ? 'flex-start' : 'center', gap: isMobile ? 20 : 40, marginTop: 8 }}>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.48)', fontWeight: 300, lineHeight: 1.75, maxWidth: 380, margin: 0 }}>
              Escolha um livro e gere um roteiro viral com IA — pronto para TikTok, Shorts ou YouTube.
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 28, height: 1, background: 'rgba(255,190,77,0.2)' }} />
              <div style={{ textAlign: 'center' }}>
                <p style={{ fontFamily: 'Space Mono, monospace', fontSize: isMobile ? 18 : 22, fontWeight: 700, color: '#ffbe4d', margin: 0, lineHeight: 1 }}>
                  <AnimatedCounter target={1247} />
                </p>
                <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 8, color: 'rgba(255,255,255,0.32)', margin: '4px 0 0', letterSpacing: '0.18em', fontWeight: 300 }}>ROTEIROS GERADOS</p>
              </div>
              <div style={{ width: 28, height: 1, background: 'rgba(255,190,77,0.2)' }} />
            </div>
          </div>
        </div>

        {/* Search + count */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, animation: 'bwFadeIn 0.7s 0.1s ease both' }}>
          <div style={{ position: 'relative', flex: 1, maxWidth: isMobile ? '100%' : 400 }}>
            <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 13, color: 'rgba(255,255,255,0.16)', pointerEvents: 'none' }}>⌕</span>
            <input
              type="text" placeholder="Buscar título ou autor..." value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                width: '100%', background: 'rgba(255,255,255,0.025)',
                border: '1px solid rgba(255,255,255,0.065)', borderRadius: 10,
                padding: '10px 14px 10px 40px', fontSize: 13,
                color: 'white', fontFamily: 'DM Sans, sans-serif', fontWeight: 300,
              }}
            />
          </div>
          <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 8, color: 'rgba(255,255,255,0.2)', letterSpacing: '0.18em', whiteSpace: 'nowrap' }}>
            {filtered.length} LIVROS
          </span>
        </div>

        {/* Filtros — scroll horizontal no mobile */}
        <div className="bw-cat-scroll" style={{ marginBottom: 36, animation: 'bwFadeIn 0.7s 0.15s ease both' }}>
          {CATS.map(c => (
            <button key={c} className="bw-cat" onClick={() => setCat(c)} style={{
              fontFamily: 'DM Sans, sans-serif', fontSize: 11, padding: '5px 14px', borderRadius: 20,
              border: `1px solid ${cat === c ? 'rgba(255,190,77,0.32)' : 'rgba(255,255,255,0.06)'}`,
              background: cat === c ? 'rgba(255,190,77,0.08)' : 'transparent',
              color: cat === c ? '#ffbe4d' : 'rgba(255,255,255,0.42)',
              cursor: 'pointer', transition: 'all 0.15s', fontWeight: cat === c ? 500 : 400,
            }}>{c}</button>
          ))}
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '70px 0', border: '1px dashed rgba(255,190,77,0.07)', borderRadius: 16 }}>
            <p style={{ fontFamily: 'Cormorant Garamond, serif', fontSize: 20, color: 'rgba(255,255,255,0.28)', fontStyle: 'italic' }}>Nenhum livro encontrado.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {rows.map((row, rowIdx) => (
              <div key={rowIdx}>
                {rowIdx > 0 && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, margin: isMobile ? '20px 0' : '28px 0' }}>
                    <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
                    <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 7, letterSpacing: '0.3em', color: 'rgba(255,190,77,0.18)' }}>
                      {String(rowIdx * cols + 1).padStart(2, '0')}–{String(Math.min(rowIdx * cols + row.length, filtered.length)).padStart(2, '0')}
                    </span>
                    <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.04)' }} />
                  </div>
                )}
                <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: isMobile ? 10 : 16 }}>
                  {row.map((book, i) => (
                    <BookCard key={book.title} book={book} index={rowIdx * cols + i} onClick={setSelectedBook} isMobile={isMobile} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginTop: 60, paddingTop: 24, borderTop: '1px solid rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: 'Space Mono, monospace', fontSize: 7, letterSpacing: '0.3em', color: 'rgba(255,255,255,0.1)' }}>VIRALNEWS · BIBLIOTECA</span>
          <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.18)', fontWeight: 300 }}>1.247 roteiros gerados hoje</span>
        </div>
      </main>

      {selectedBook && <BooksModal book={selectedBook} onClose={() => setSelectedBook(null)} isMobile={isMobile} />}
    </div>
  );
}
