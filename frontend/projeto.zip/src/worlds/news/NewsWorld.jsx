import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScriptGenerator } from '../../hooks/useScriptGenerator';
import { ScriptModal } from '../../components/script/ScriptModal';

const CATEGORIES = [
  { id:'general', label:'Geral' },
  { id:'technology', label:'Tech' },
  { id:'health', label:'Saúde' },
  { id:'science', label:'Ciência' },
  { id:'business', label:'Negócios' },
  { id:'entertainment', label:'Entretenimento' },
];

export function NewsWorld() {
  const navigate = useNavigate();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState('general');
  const [selected, setSelected] = useState(null);
  const generator = useScriptGenerator();

  const fetchNews = useCallback(async (cat) => {
    setLoading(true);
    try {
      const r = await fetch('/api/news?category='+cat+'&source=br');
      const d = await r.json();
      setArticles((d.articles || d).slice(0, 30));
    } catch(e) { setArticles([]); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchNews(category); }, [category]);

  const accent = '#5b9bff';
  const glow = '91,155,255';

  return (
    <div style={{ minHeight:'100vh', background:'#04080f', color:'#fff', fontFamily:'DM Sans, sans-serif', position:'relative' }}>
      <style dangerouslySetInnerHTML={{__html:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=DM+Sans:wght@300;400;500&family=Space+Mono:wght@400;700&display=swap');
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(91,155,255,0.3);border-radius:2px}
        .news-row:hover{background:rgba(91,155,255,0.05)!important;border-color:rgba(91,155,255,0.25)!important}
        .cat-btn:hover{color:#fff!important;border-color:rgba(91,155,255,0.4)!important}
        @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}
        @keyframes spin{to{transform:rotate(360deg)}}
      `}} />

      {/* Header glassmorphism */}
      <header style={{ position:'sticky', top:0, zIndex:50, height:56, display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px', background:'rgba(4,8,15,0.8)', backdropFilter:'blur(32px)', WebkitBackdropFilter:'blur(32px)', borderBottom:'1px solid rgba(91,155,255,0.12)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          <button onClick={() => navigate('/')} style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.22em', color:'rgba(255,255,255,0.4)', background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:6, padding:0 }}>
            {String.fromCharCode(8592)} PORTAL
          </button>
          <span style={{ color:'rgba(255,255,255,0.1)' }}>|</span>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background:accent, boxShadow:'0 0 10px rgba('+glow+',0.9)', animation:'pulse 2s ease-in-out infinite' }} />
            <span style={{ fontFamily:'Playfair Display, serif', fontSize:18, fontWeight:700, color:'#fff', letterSpacing:'-0.5px' }}>Notícias</span>
          </div>
        </div>
        <span style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.28em', color:'rgba(255,255,255,0.25)' }}>AO VIVO</span>
      </header>

      {/* Hero title - editorial */}
      <div style={{ padding:'40px 24px 24px', borderBottom:'1px solid rgba(255,255,255,0.06)', background:'linear-gradient(180deg, rgba(91,155,255,0.04) 0%, transparent 100%)' }}>
        <p style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.5em', color:'rgba(91,155,255,0.6)', marginBottom:10 }}>ROTEIROS VIRAIS</p>
        <h1 style={{ fontFamily:'Playfair Display, serif', fontSize:'clamp(32px,6vw,64px)', fontWeight:900, margin:'0 0 6px', lineHeight:0.92, letterSpacing:'-2px' }}>
          <span style={{ fontStyle:'italic', color:'#fff' }}>Breaking</span>{' '}
          <span style={{ color:'transparent', WebkitTextStroke:'1.5px rgba(255,255,255,0.8)' }}>News</span>
        </h1>
        <p style={{ fontFamily:'DM Sans', fontSize:13, color:'rgba(255,255,255,0.45)', margin:'8px 0 0', fontWeight:300 }}>Escolha uma notícia e gere seu roteiro com IA</p>
      </div>

      {/* Categories - glass pills */}
      <div style={{ padding:'16px 24px', display:'flex', gap:8, flexWrap:'wrap', borderBottom:'1px solid rgba(255,255,255,0.05)', background:'rgba(4,8,15,0.6)', backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)', position:'sticky', top:56, zIndex:40 }}>
        {CATEGORIES.map(cat => (
          <button key={cat.id} className="cat-btn" onClick={() => setCategory(cat.id)} style={{
            padding:'6px 16px', borderRadius:20, border: category===cat.id ? '1px solid rgba('+glow+',0.6)' : '1px solid rgba(255,255,255,0.08)',
            background: category===cat.id ? 'rgba('+glow+',0.15)' : 'rgba(255,255,255,0.04)',
            backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)',
            color: category===cat.id ? accent : 'rgba(255,255,255,0.45)',
            fontFamily:'DM Sans', fontSize:12, fontWeight:500, cursor:'pointer', transition:'all 0.2s', whiteSpace:'nowrap',
          }}>{cat.label}</button>
        ))}
      </div>

      {/* Feed */}
      <div style={{ maxWidth:860, margin:'0 auto', padding:'24px 24px 80px' }}>
        {loading && (
          <div style={{ textAlign:'center', padding:'80px 0' }}>
            <div style={{ width:28, height:28, borderRadius:'50%', border:'2px solid rgba('+glow+',0.2)', borderTopColor:accent, animation:'spin 0.8s linear infinite', margin:'0 auto 16px' }} />
            <p style={{ fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.2em', color:'rgba(255,255,255,0.25)' }}>CARREGANDO NOTÍCIAS</p>
          </div>
        )}
        {!loading && articles.map((article, i) => (
          <NewsRow key={article.id||i} article={article} index={i} onSelect={(a, opts) => {
            setSelected(a); generator.reset(); generator.generate(a, opts);
          }} />
        ))}
      </div>

      {selected && <ScriptModal article={selected} generator={generator} onClose={() => setSelected(null)} onGenerate={(opts) => generator.generate(selected, opts)} />}
    </div>
  );
}

function NewsRow({ article, index, onSelect }) {
  const [hovered, setHovered] = useState(false);
  const [showOpts, setShowOpts] = useState(false);
  const [platform, setPlatform] = useState('youtube_shorts');
  const [style, setStyle] = useState('educational');
  const accent = '#5b9bff';
  const glow = '91,155,255';

  const score = article.viral_score || 0;
  const scoreColor = score >= 8 ? '#00e5b0' : score >= 6 ? '#ffbe4d' : '#ff6b6b';

  return (
    <div className="news-row" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{ padding:'20px 0', borderBottom:'1px solid rgba(255,255,255,0.06)', transition:'all 0.2s', borderRadius:4, animation:'fadeIn 0.4s ease both', animationDelay:(index*0.03)+'s' }}>
      <div style={{ display:'flex', gap:16, alignItems:'flex-start' }}>
        <span style={{ fontFamily:'Space Mono', fontSize:10, color:'rgba(91,155,255,0.35)', flexShrink:0, marginTop:3, minWidth:26 }}>{String(index+1).padStart(2,'0')}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6, flexWrap:'wrap' }}>
            {article.source && <span style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.15em', color:'rgba(255,255,255,0.3)', background:'rgba(255,255,255,0.04)', padding:'2px 8px', borderRadius:3, border:'1px solid rgba(255,255,255,0.06)' }}>{typeof article.source === 'string' ? article.source : (article.source?.name || 'RSS')}</span>}
            <span style={{ fontFamily:'Space Mono', fontSize:8, letterSpacing:'0.15em', color:scoreColor, border:'1px solid '+scoreColor+'44', background:scoreColor+'11', padding:'2px 8px', borderRadius:3 }}>{score >= 8 ? 'VIRAL' : score >= 6 ? 'POTENCIAL' : 'NORMAL'}</span>
          </div>
          <p style={{ fontFamily:'DM Sans', fontSize:14, color:'rgba(255,255,255,0.88)', margin:'0 0 8px', lineHeight:1.55, fontWeight:400 }}>{article.title}</p>
          {article.description && <p style={{ fontFamily:'DM Sans', fontSize:12, color:'rgba(255,255,255,0.38)', margin:'0 0 10px', lineHeight:1.5, fontWeight:300 }}>{article.description?.slice(0,100)}{article.description?.length > 100 ? '...' : ''}</p>}
          {showOpts && (
            <div style={{ marginTop:12, display:'flex', gap:8, flexWrap:'wrap', alignItems:'center', padding:'14px 16px', background:'rgba(91,155,255,0.06)', backdropFilter:'blur(16px)', WebkitBackdropFilter:'blur(16px)', border:'1px solid rgba(91,155,255,0.18)', borderRadius:10 }}>
              <select value={platform} onChange={e => setPlatform(e.target.value)} style={{ background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:6, padding:'6px 10px', color:'rgba(255,255,255,0.8)', fontSize:11, cursor:'pointer', fontFamily:'DM Sans' }}>
                <option value="tiktok">TikTok</option>
                <option value="youtube_shorts">YouTube Shorts</option>
                <option value="youtube_long">YouTube Longo</option>
              </select>
              <select value={style} onChange={e => setStyle(e.target.value)} style={{ background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:6, padding:'6px 10px', color:'rgba(255,255,255,0.8)', fontSize:11, cursor:'pointer', fontFamily:'DM Sans' }}>
                <option value="educational">Educacional</option>
                <option value="storytelling">Storytelling</option>
                <option value="dark_channel">Entretenimento</option>
                <option value="controversial">Debate</option>
              </select>
              <button onClick={() => onSelect(article, { platform, style })} style={{ padding:'7px 18px', background:'rgba('+glow+',0.18)', border:'1px solid rgba('+glow+',0.5)', borderRadius:6, color:accent, fontFamily:'Space Mono', fontSize:9, letterSpacing:'0.18em', cursor:'pointer', marginLeft:'auto' }}>
                GERAR {String.fromCharCode(8594)}
              </button>
            </div>
          )}
        </div>
        <button onClick={() => setShowOpts(!showOpts)} style={{
          padding:'7px 14px', border: showOpts ? '1px solid rgba('+glow+',0.5)' : '1px solid rgba(255,255,255,0.1)',
          borderRadius:8, background: showOpts ? 'rgba('+glow+',0.12)' : 'rgba(255,255,255,0.04)',
          backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)',
          color: showOpts ? accent : 'rgba(255,255,255,0.4)', fontFamily:'Space Mono', fontSize:9,
          letterSpacing:'0.12em', cursor:'pointer', flexShrink:0, transition:'all 0.2s',
        }}>{showOpts ? 'FECHAR' : 'USAR'}</button>
      </div>
    </div>
  );
}
