import { useState, useCallback } from 'react';
import { generateApi } from '../services/api';
import { storageService } from '../services/storage';
import { useLang } from '../contexts/LanguageContext';

const DEFAULT_PLATFORM = 'youtube_shorts';
const DEFAULT_STYLE = 'storytelling';

export function useScriptGenerator() {
  const { lang } = useLang();
  const [platform, setPlatform] = useState(DEFAULT_PLATFORM);
  const [style, setStyle] = useState(DEFAULT_STYLE);
  const [script, setScript] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hooksLoading, setHooksLoading] = useState(false);
  const [currentVersion, setCurrentVersion] = useState(1);

  // Aceita (article, version) ou (article, { platform, style, version })
  const generate = useCallback(async (article, versionOrOpts = 1) => {
    let version = 1;
    let overridePlatform = null;
    let overrideStyle = null;

    if (typeof versionOrOpts === 'object' && versionOrOpts !== null) {
      version = versionOrOpts.version || 1;
      overridePlatform = versionOrOpts.platform || null;
      overrideStyle = versionOrOpts.style || null;
    } else {
      version = versionOrOpts || 1;
    }

    const effectivePlatform = overridePlatform || platform;
    const effectiveStyle = overrideStyle || style;

    if (overridePlatform) setPlatform(overridePlatform);
    if (overrideStyle) setStyle(overrideStyle);

    setLoading(true);
    setError(null);
    setScript(null);
    setCurrentVersion(version);

    try {
      const data = await generateApi.createScript({
        article,
        platform: effectivePlatform,
        style: effectiveStyle,
        version,
        lang,
      });
      setScript(data.script);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [platform, style, lang]);

  const generateVersion = useCallback(async (article, version) => {
    await generate(article, version);
  }, [generate]);

  const regenerateHooks = useCallback(async (article) => {
    if (!script) return;
    setHooksLoading(true);
    try {
      const data = await generateApi.regenerateHooks({
        article,
        platform,
        style,
        existingHooks: script.hooks,
        lang,
      });
      setScript((prev) => ({ ...prev, hooks: data.hooks }));
    } catch (err) {
      setError(err.message);
    } finally {
      setHooksLoading(false);
    }
  }, [script, platform, style, lang]);

  const saveScript = useCallback((article) => {
    if (!script) return null;
    return storageService.save({
      ...script,
      article_image: article?.image,
      article_source: article?.source,
    });
  }, [script]);

  const reset = useCallback(() => {
    setScript(null);
    setError(null);
    setCurrentVersion(1);
  }, []);

  return {
    platform, setPlatform,
    style, setStyle,
    script, loading, error, hooksLoading,
    currentVersion,
    generate, generateVersion,
    regenerateHooks,
    saveScript,
    reset,
  };
}
